
CS221 Project 1

Student1: n3l0b; Hyung Ro Lee; 49806102
Student2: l3k0b; Jimin Jeon  ; 24832140

List of files:
LQueue_driver.C
LQueue.C
LQueue.h
Makefile
README.txt
runway.C
runway1.C (this is a only one runway version - simply switch the file name to run)

NOTE: ‘make’ will create both runway / LQueue_driver (runnable files) by default

NOTES about each part:

1. LQueue_driver

- LQueue_driver will first ask which number to move to front and if the number is not in the queue, it will do nothing.
- Subsequently, it will merge q1 with q3 where the queue is hardcoded.
(ASSUMPTION: each queue is sorted before merged. 여기 추가 좀 더 해줘..)


2. runway

- runway is consist of two parts, 1) using 2 runways, 2) using 1 runway
- The program will ask to choose how many runways to manage, 
if pressed 1, program will run within switch case 1
if pressed 2, program will run within switch case 2
NOTE: in the main function, case 2 is before case 1

- When the simulation time is done, it will not generate planes any more but program will continue to run until the queues are empty

etc…

